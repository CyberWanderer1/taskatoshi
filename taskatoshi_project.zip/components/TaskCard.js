import { useState } from "react"

export default function TaskCard({task}){

const [proof,setProof] = useState("")

function share(){

const text = "I just earned BTC completing a task on Taskatoshi ⚡"

window.open(
`https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}`
)

}

return(

<div style={{
border:"1px solid #ddd",
padding:"20px",
marginBottom:"20px"
}}>

<h3>{task.title}</h3>

<p>Reward: {task.reward} BTC</p>

<input
placeholder="Submit proof link"
value={proof}
onChange={(e)=>setProof(e.target.value)}
/>

<button onClick={share}>
Submit & Share
</button>

</div>

)

}